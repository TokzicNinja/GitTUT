#ifndef COMPOSITE_H
#define COMPOSITE_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Menu //Component
{     
public:    
    virtual void add(Menu*)=0;
    virtual void print()=0;
};

class PizzaMenu: public Menu//composite
{
public:
    PizzaMenu(std::string n);
    ~PizzaMenu();
    void add(Menu*);
    void print();
private:
    std::vector<Menu*> next;  
    std::string name; 
    int cost; 
};

class PastaMenu: public Menu//composite
{
public:
    PastaMenu(std::string n);
    ~PastaMenu();
    void add(Menu*);
    void print();

private:
    std::vector<Menu*> next;
    int cost;
    std::string name;
};

class ChocolateMenu: public Menu//composite
{
public:
    ChocolateMenu(std::string s);
    ~ChocolateMenu();
    void add(Menu*);
    void print();
private:
    std::vector<Menu*> next; 
    int cost;
    std::string name;
};

class Primitive: public Menu
{
public:
    Primitive(std::string n,int c);
    ~Primitive();
     void print();
     void add(Menu* product);
private:
    std::string name;
    int cost;
    // vector<Menu*> next;
};

#endif  