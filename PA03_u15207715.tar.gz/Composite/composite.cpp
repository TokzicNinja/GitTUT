#include "composite.h"


void PizzaMenu::add(Menu* product)
{
    next.push_back(product);
}

PizzaMenu::PizzaMenu(std::string n):name(n)
{
    name = n;
}

PizzaMenu::~PizzaMenu()
{}

void PizzaMenu::print()
{
    cout<<"The Yummy "<<name<<" Menu"<<endl;    
    vector<Menu*>:: iterator i;  
    for(i = next.begin();i!=next.end();i++)
    {
        (*i)->print();
    }    
}    

void PastaMenu::add(Menu* product)
{
    next.push_back(product);
}


PastaMenu::PastaMenu(std::string n):name(n)
{
    name = n;    
}

PastaMenu::~PastaMenu()
{}

void PastaMenu::print()
{
    cout<<"The Yummy "<<name<<" Menu"<<endl;    
    vector<Menu*>:: iterator i;  
    for(i = next.begin();i!=next.end();i++)
    {
        (*i)->print();
    }    
}

ChocolateMenu::ChocolateMenu(std::string n):name(n)
{
    name = n;
}

ChocolateMenu::~ChocolateMenu()
{}

void ChocolateMenu::add(Menu* product)
{
    next.push_back(product);
}

void ChocolateMenu::print()
{
    cout<<"The Yummy "<<name<<" Menu"<<endl;    
    vector<Menu*>:: iterator i;  
    for(i = next.begin();i!=next.end();i++)
    {
        (*i)->print();
    }    
}

Primitive::Primitive(std::string n,int c):name(n),cost(c)
{}

Primitive::~Primitive()
{}

void Primitive::print()
{
    cout<<name<<" R"<<cost<<endl;
}

void Primitive::add(Menu* product)
{
    // next.push_back(product);
    cout<<"Adding"<<endl;
}

    

