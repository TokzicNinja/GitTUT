#include <iostream>
#include "composite.h"
using namespace std;

int main()
{
  // Menu myMenu =  Menu("Menu");
  PizzaMenu myPizza =  PizzaMenu("Pizza");                 
  PastaMenu myPasta =  PastaMenu("Pasta");           
  ChocolateMenu myChocolate =  ChocolateMenu("Chocolate");  
//primitives  
  Primitive haw = Primitive("Hawaiian",20);
  Primitive reg = Primitive("Regina",20);
  Primitive mm = Primitive("Mighty Meat",20);
  
  Primitive bol = Primitive("bolognaise",20);
  Primitive las = Primitive("beef lasagne",20);
  Primitive alf = Primitive("ham alfred",20);
  
  Primitive lin = Primitive("Lindt",20);
  Primitive cad = Primitive("Cadbury",20);
  Primitive milky = Primitive("MilkyBar",20);
  
	myPizza.add(&haw);
	myPizza.add(&reg);
	myPizza.add(&mm);
	
	myPasta.add(&bol);
	myPasta.add(&las);
	myPasta.add(&alf);
	
	myChocolate.add(&lin);
	myChocolate.add(&cad);
	myChocolate.add(&milky);

  // myMenu.add(&myPizza);
  // myMenu.add(&myPasta);
  // myMenu.add(&myChocolate);  

  // myMenu.traverse();
  myPizza.print();
  myPasta.print();
  myChocolate.print();
  cout << '\n';                 
}