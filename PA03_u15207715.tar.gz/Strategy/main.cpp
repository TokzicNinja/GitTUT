#include "Context.h"
#include <iostream>

using namespace std;

int main()
{   
    int fare;
    Context* mode = new Context();
    cout<<"Enter your budget:\n";
    cin>>fare;
    
    cout<<mode->transportMethod(fare)<<endl;


    return 0;
}