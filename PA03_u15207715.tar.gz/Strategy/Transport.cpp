#include "Transport.h"

Transport::~Transport()
{}

int Uber::transportMethod(int fare)
{
    return (fare - 200);
}

std::string Uber::getMethod()
{
    return "Uber";
}

int Gautrain::transportMethod(int fare)
{
    return (fare - 50);
}

std::string Gautrain::getMethod()
{
    return "Gautrain";
}

int Taxi::transportMethod(int fare)
{
    return (fare - 5);
}

std::string Taxi::getMethod()
{
    return "Taxi";
}