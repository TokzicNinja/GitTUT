#ifndef TRANSPORT_H
#define TRANSPORT_H

#include <string>
#include <iostream>

using namespace std;

class Context;
class Transport
{
public:
    virtual ~Transport();
    virtual int transportMethod(int fare)=0;
    virtual std::string getMethod()=0;
};

class Uber : public Transport
{
public:
    int transportMethod(int fare);
    std::string getMethod();
};

class Gautrain : public Transport
{
public:
    int transportMethod(int fare);
    std::string getMethod();
};

class Taxi : public Transport
{
public:
    int transportMethod(int fare);
    std::string getMethod();
};

#endif