#include "Context.h"

int Context::transportMethod(int fare)
{
    if(fare>=200)
        {
            delete transport;
            transport = new Uber();
            cout<<"Uber\n";
            cout<<"Budget after travels: ";return transport->transportMethod(fare);
            cout<<endl;
        }
    else if(fare>=50 && fare<=200)
        {
            delete transport;
            transport = new Gautrain();
            cout<<"Gautrain\n";
            cout<<"Budget after travels: ";return transport->transportMethod(fare);
        }
    else if(fare>=5 && fare<=50)
        {
            delete transport;
            transport = new Taxi();
            cout<<"Taxi\n";
            cout<<"Budget after travels: ";return transport->transportMethod(fare);
        }
    else 
        {
            cout<<"Ekse dawg you are broke, you better walk!!!"<<endl;
            return -1;
         }

    // if(transport!=NULL)
    //     delete transport;
}

Context::~Context()
{
    delete transport; 
}

Context::Context()
{
    transport = new Uber();
}

