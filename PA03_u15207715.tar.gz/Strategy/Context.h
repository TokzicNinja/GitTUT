#ifndef CONTEXT_H
#define CONTEXT_H

#include "Transport.h"
#include <iostream>

using namespace std;

class Transport;
class Context{

private:
    Transport* transport;
public:
    Context();
    ~Context();
    int transportMethod(int fare);
};

#endif