#include <iostream>
#include "Awareness.h"
#include <string>

using namespace std;

int main()
{   
    std::string player;
    cout<<"Player: ";
    std::getline(cin,player);
    Awareness* enemy = new  Awareness();
    bool condi = true;

    while(condi)
    {
        cout<<"Player: ";
        std::getline(cin,player);
        
        if(player=="run past enemy"||player=="Run past enemy")
        {
            enemy->change();  
            condi = true; 
        }
        else if(player=="Break a vase"||player=="break a vase")
        {  
            enemy->change();
            condi = true;
        }
        else if(player=="Poke the enemy"||player=="poke the enemy")
        {
            enemy->change();
            condi = true;
        }
        else if(player=="Charge at the enemy"||player=="charge at the enemy")
        {
            enemy->change();  
            condi = true;
        }
        else if(player=="run away"||player=="Run away")
        {
            enemy->change();
            condi = true;
        }
        else
        {
            condi= false;            
        }
    }
    delete enemy;
    cout<<"Program has eneded"<<endl;

    return 0;
}