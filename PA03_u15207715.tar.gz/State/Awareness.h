#ifndef AWARENESS_H
#define AWARENESS_H

#include "State.h"

class State;
class Awareness
{
protected:
    State *state;
public:
    Awareness();
    ~Awareness();
    void change();
    void setAwareness(State* s);
    // void idle();
    // void alert();
    // void searching();
    // void attacking();
};

#endif