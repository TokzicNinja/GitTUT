#ifndef STATE_H
#define STATE_H

#include "Awareness.h"

class Awareness;
class State
{
public:
    // virtual void idle(Awareness* a);
    // virtual void alert(Awareness* a);
    // virtual void searching(Awareness* a);
    // // virtual void attacking(Awareness* a);
    virtual void handle(Awareness* a)=0;
    virtual ~State(){};
};

//state1
class Idle:public State
{
public:
    Idle();
    ~Idle();
    // void idle(Awareness* a);//add context as parameter;
    void handle(Awareness* a);    
};

//state2
class Alert:public State
{
public:
    Alert();
    ~Alert();
    // void alert(Awareness* a);//add context as parameter;
     void handle(Awareness* a);    
};

//state3
class Searching:public State
{
public:
    Searching();
    ~Searching();
    // void searching(Awareness* a);//add context as parameter
     void handle(Awareness* a);
};

//state4
class Attacking:public State
{
public:
    Attacking();
    ~Attacking();
    // void attacking(Awareness* a);//add context as parameter
    void handle(Awareness* a);    
};


#endif