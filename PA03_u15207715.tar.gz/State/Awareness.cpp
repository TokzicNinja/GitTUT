#include <iostream>
#include "Awareness.h"

using namespace std;

Awareness::Awareness()
{
    this->state = new Idle();
}

Awareness::~Awareness()
{
    delete this->state;
}

void Awareness::setAwareness(class State* state)
{
    delete this->state;
    this->state = state;
}

void Awareness::change()
{
    state->handle(this);
}

// void Awareness::idle()
// {
//     cout<<"calling idle"<<endl;
//     state->idle(this);
// }

// void Awareness::alert()
// {
//     cout<<"calling alert"<<endl;
//     state->alert(this);
// }

// void Awareness::searching()
// {
//     cout<<"calling searching"<<endl;
//     state->searching(this);
// }

// void Awareness::attacking()
// {
//     cout<<"calling attacking"<<endl;
//     state->attacking(this);
// }

