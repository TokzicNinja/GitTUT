#include <iostream>
#include "State.h"

using namespace std;

//for idle
Idle::Idle()
{
    cout<<"*whistling*"<<endl;
}

Idle::~Idle()
{}

void Idle::handle(Awareness* a)
{
    a->setAwareness(new Alert());
}
// void Idle::idle(Awareness* a)//add context as parameter;
// {
//     delete this;
//     a->setAwareness(new Alert());
// }
//for alerting
Alert::Alert()
{
    cout<<"I sense an intruder! I better start searching for him"<<endl;
}

Alert::~Alert()
{}

void Alert::handle(Awareness* a)
{
    a->setAwareness(new Searching());
}

// void Alert::alert(Awareness* a)
// {
//     delete this;
//     a->setAwareness(new Searching());
// }    
//for searching
Searching::Searching()
{
    cout<<"*looking around confused*"<<endl;
}

Searching::~Searching()
{}
 
void Searching::handle(Awareness* a)
{
    a->setAwareness(new Attacking());
}
// void Searching::searching(Awareness* a)
// {
//     delete this;
//     a->setAwareness(new Attacking());
// }

//for attacking
Attacking::Attacking()
{
    cout<<"I found you scum! Eat my sword"<<endl;
}

Attacking::~Attacking()
{}

void Attacking::handle(Awareness* a)
{
    a->setAwareness(new Idle());
}
// void Attacking::attacking(Awareness* a)
// {
//     delete this;
//     a->setAwareness(new Attacking());
// }

//for for the state
// void State::idle(Awareness* a)
// {
//     cout<<"Idle state"<<endl;
// }

// void State::alert(Awareness* a)
// {
//     cout<<"Alert state"<<endl;
// }

// void State::searching(Awareness* a)
// {
//     cout<<"Searching state"<<endl;
// }

// void State::attacking(Awareness* a)
// {
//     cout<<"Attacking state"<<endl;
// }